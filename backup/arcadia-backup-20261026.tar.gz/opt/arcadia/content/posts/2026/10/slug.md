---
title: Slug
date: 2026-10-17 15:05
category: 杂谈
---

- **/etc：**  
    etc 是 Etcetera(等等) 的缩写,这个目录用来存放所有的系统管理所需要的配置文件和子目录。




在 Linux 中我们可以使用 ll 或者 ls –l 命令来显示一个文件的属性以及文件所属的用户和组，如：
![16e1e3a9987e992f92dd6e53a94cfb2d](/assets/2026/10/9f8932c633f4.jpg)

[root@www /]# ls -l
total 64
dr-xr-xr-x   2 root root 4096 Dec 14  2012 bin
dr-xr-xr-x   4 root root 4096 Apr 19  2012 boot
……

实例中，**bin** 文件的第一个属性用 d 表示。d 在 Linux 中代表该文件是一个目录文件。

在 Linux 中第一个字符代表这个文件是目录、文件或链接文件等等。

- 当为 d 则是目录
- 当为 - 则是文件；
- 若是 l 则表示为链接文档(link file)；
- 若是 b 则表示为装置文件里面的可供储存的接口设备(可随机存取装置)；
- 若是 c 则表示为装置文件里面的串行端口设备，例如键盘、鼠标(一次性读取装置)。

接下来的字符中，以三个为一组，且均为 rwx 的三个参数的组合。其中， r 代表可读(read)、 w 代表可写(write)、 x 代表可执行(execute)。 要注意的是，这三个权限的位置不会改变，如果没有权限，就会出现减号 - 而已。

![[Pasted image 20251101143903.png]]

对于文件来说，它都有一个特定的所有者，也就是对该文件具有所有权的用户。

同时，在Linux系统中，用户是按组分类的，一个用户属于一个或多个组。

文件所有者以外的用户又可以分为文件所属组的同组用户和其他用户。

因此，Linux系统按文件所有者、文件所有者同组用户和其他用户来规定了不同的文件访问权限。

在以上实例中，mysql 文件是一个目录文件，属主和属组都为 mysql，属主有可读、可写、可执行的权限；与属主同组的其他用户有可读和可执行的权限；其他用户也有可读和可执行的权限。

对于 root 用户来说，一般情况下，文件的权限对其不起作用。


HDMI&Mini HDMI&Micro HDMI使用转接器有协议不兼容的问题（三托三HDMI线？）

![[Pasted image 20251101145611.png]]

- **绝对路径：**  
    路径的写法，由根目录 / 写起，例如： /usr/share/doc 这个目录。
    
- **相对路径：**  
    路径的写法，不是由 / 写起，例如由 /usr/share/doc 要到 /usr/share/man 底下时，可以写成： cd ../man 这就是相对路径的写法。


- ls（英文全拼：list files）: 列出目录及文件名
- cd（英文全拼：change directory）：切换目录
- pwd（英文全拼：print work directory）：显示目前的目录
- mkdir（英文全拼：make directory）：创建一个新的目录
- rmdir（英文全拼：remove directory）：删除一个空的目录
- cp（英文全拼：copy file）: 复制文件或目录
- rm（英文全拼：remove）: 删除文件或目录
- mv（英文全拼：move file）: 移动文件与目录，或修改文件与目录的名称

/home/arcadia/noob

- **df**（英文全称：disk free）：列出文件系统的整体磁盘使用量
- **du**（英文全称：disk used）：检查磁盘空间使用量
- **fdisk**：用于磁盘分区


## vi/vim 的使用

基本上 vi/vim 共分为三种模式，**命令模式（Command Mode）、输入模式（Insert Mode）和命令行模式（Command-Line Mode）**。

### 命令模式

**用户刚刚启动 vi/vim，便进入了命令模式。**

此状态下敲击键盘动作会被 Vim 识别为命令，而非输入字符，比如我们此时按下 i，并不会输入一个字符，i 被当作了一个命令。

以下是普通模式常用的几个命令：
- i -- 切换到输入模式，在光标当前位置开始输入文本。
- - x -- 删除当前光标所在处的字符。
- - a -- 进入插入模式，在光标下一个位置开始输入文本。
- - yy -- 复制当前行。
- - :w -- 保存文件。
- - :q! -- 强制退出Vim 编辑器，不保存修改。

查看一些可更新的包：
sudo apt update

升级安装包：
sudo apt upgrade

# 复制/移动/删除
```
cp file1.txt file2.txt
mv oldname.txt newname.txt
rm file.txt
rm -r folder/  # 递归删除目录

cat filename      # 显示整个文件
less filename     # 分页查看
head -n 10 file   # 查看前10行
tail -f logfile   # 实时查看日志
```

## Shell脚本编写&使用
#!/bin/bash
echo "Hello World !"


```
`chmod +x ./test.sh #使脚本具有执行权限` 
`./test.sh #执行脚本`
```


%% 等号两侧避免使用空格： %%
### 使用变量

使用一个定义过的变量，只要在变量名前面加美元符号即可，如：
```
`your_name="qinjx"`
`echo $your_name`
`echo ${your_name}`

```

已定义的变量，可以被重新定义，如：

## 实例

```
`your_name="tom"`  
`echo $your_name`  
`your_name="alibaba"`  
`echo $your_name`  
```

这样写是合法的，但注意，第二次赋值的时候不能写
`$your_name="alibaba"`，使用变量的时候才加美元符$。

使用 unset 命令可以删除变量。语法：
`unset variable_name`

使用 readonly 命令可以将变量定义为只读变量，只读变量的值不能被改变。
`readonly myUrl`

```
#---------------------
#这是一个注释
#Bonjour
#---------------------
```

```
`: '`
`这是注释内容`
`'`
```

| 参数处理 | 说明                                                                             |
| ---- | ------------------------------------------------------------------------------ |
| $#   | 传递到脚本的参数个数                                                                     |
| $*   | 以一个单字符串显示所有向脚本传递的参数。  <br>如"$*"用「"」括起来的情况、以"$1 $2 … $n"的形式输出所有参数。              |
| $$   | 脚本运行的当前进程ID号                                                                   |
| $!   | 后台运行的最后一个进程的ID号                                                                |
| $@   | 与$*相同，但是使用时加引号，并在引号中返回每个参数。  <br>如"$@"用「"」括起来的情况、以"$1" "$2" … "$n" 的形式输出所有参数。  |
| $-   | 显示Shell使用的当前选项，与[set命令](https://www.runoob.com/linux/linux-comm-set.html)功能相同。 |
| $?   | 显示最后命令的退出状态。0表示没有错误，其他任何值表明有错误。                                                |
|      |                                                                                |

```
echo "-- \$* 演示 ---"
for i in "$*"; do
    echo $i
done

echo "-- \$@ 演示 ---"
for i in "$@"; do
    echo $i
done
```
```
执行脚本，输出结果如下所示：

$ chmod +x test.sh 
$ ./test.sh 1 2 3
-- $* 演示 ---
1 2 3
-- $@ 演示 ---
1
2
3
```

```
my_array=(A B "C" D)

echo "第一个元素为：${my_array[0]}"
echo "第二个元素为：${my_array[1]}"
echo "第三个元素为：${my_array[2]}"
echo "第四个元素为：${my_array[3]}"
```

**注意：**条件表达式要放在方括号之间，并且要有空格，例如: **[$a==$b]** 是错误的，必须写成 **[ $a == $b ]**。


### -n 选项：不换行输出
默认情况下，`echo` 会在输出后添加换行符。使用 `-n` 可以禁止这种行为：
## 实例
```
echo -n "Loading..."  
echo " Done!"
```
**执行结果**：
```
Loading... Done!
```

使用重定向将输出保存到文件：
```
## 实例
echo "This will be saved to file" > output.txt  
```

追加内容到文件：
```
## 实例
echo "Additional line" >> output.txt
```

生成一个进度条
```
#!/bin/bash

for i in {1..20}; do
    printf "\rProgress: [%-20s] %d%%" $(printf "%${i}s" | tr ' ' '#') $((i*5))
    sleep 0.1
done
printf "\n"
```


`test` 命令最常用于检查文件属性，以下是常用文件测试选项：

|操作符|描述|示例|
|---|---|---|
|-e|文件是否存在|`[ -e file.txt ]`|
|-f|是普通文件|`[ -f /path/to/file ]`|
|-d|是目录|`[ -d /path/to/dir ]`|
|-r|可读|`[ -r file.txt ]`|
|-w|可写|`[ -w file.txt ]`|
|-x|可执行|`[ -x script.sh ]`|
|-s|文件大小 >0|`[ -s logfile ]`|
|-L|是符号链接|`[ -L symlink ]`|
test等价于[]

if else 的 [...] 判断语句中大于使用 -gt，小于使用 -lt。
```
if [ "$a" -gt "$b" ]; then
    ...
fi
```

如果使用 ((...)) 作为判断语句，大于和小于可以直接使用 > 和 <。
```
if (( a > b )); then
    ...
fi
```

```
for loop in 1 2 3 4 5
do
    echo "The value is: $loop"
done
```

```
#!/bin/bash
int=1
while(( $int<=5 ))
do
    echo $int
    let "int++"
done
```

## until 循环

until 循环执行一系列命令直至条件为 true 时停止。

until 循环与 while 循环在处理方式上刚好相反。

一般 while 循环优于 until 循环，但在某些时候—也只是极少数情况下，until 循环更加有用。

until 语法格式:
```

until condition
do
    command
done
```

## case ... esac

**case ... esac** 为多选择语句，与其他语言中的 switch ... case 语句类似，是一种多分支选择结构，每个 case 分支用右圆括号开始，用两个分号 ;; 表示 break，即执行结束，跳出整个 case ... esac 语句，esac（就是 case 反过来）作为结束标记。
```
echo '输入 1 到 4 之间的数字:'
echo '你输入的数字为:'
read aNum
case $aNum in
    1)  echo '你选择了 1'
    ;;
    2)  echo '你选择了 2'
    ;;
    3)  echo '你选择了 3'
    ;;
    4)  echo '你选择了 4'
    ;;
    *)  echo '你没有输入 1 到 4 之间的数字'
    ;;
esac
```

## 创建自己的函数

```
#!/bin/bash
# author:菜鸟教程
# url:www.runoob.com

funWithReturn(){
    echo "这个函数会对输入的两个数字进行相加运算..."
    echo "输入第一个数字: "
    read aNum
    echo "输入第二个数字: "
    read anotherNum
    echo "两个数字分别为 $aNum 和 $anotherNum !"
    return $(($aNum+$anotherNum))
}
funWithReturn
echo "输入的两个数字之和为 $? !"
```
更好的做法：（因为return的返回值为0-255）
```
funWithReturn(){
    echo "这个函数会对输入的两个数字进行相加运算..."
    read -p "输入第一个数字: " aNum
    read -p "输入第二个数字: " anotherNum
    echo "两个数字分别为 $aNum 和 $anotherNum !"
    echo $((aNum + anotherNum))    # 用 echo 输出结果而不是 return
}

result=$(funWithReturn)
echo "输入的两个数字之和为 $result !"
```

"注意echo命令后面一定要加上空格"


输出重定向会覆盖文件内容，请看下面的例子：
```

$ echo "菜鸟教程：www.runoob.com" > users
$ cat users
菜鸟教程：www.runoob.com
$

如果不希望文件内容被覆盖，可以使用 >> 追加到文件末尾，例如：

$ echo "菜鸟教程：www.runoob.com" >> users
$ cat users
菜鸟教程：www.runoob.com
菜鸟教程：www.runoob.com
$
```

通配符
eg: ls t*  能匹配t开头的任意字数的文件

pwd打印当前绝对路径 

ls -l 看到文件全选
ls -a 看隐藏文件
mkdir 创建目录
 mkdir -p work2/work3  递归创建
 rmdir 仅删除空目录
 rm 删除文件目录，不管是否非空 加上-r删除目录。
 touch 创建一个空文件 